//
//  CameraController+simulator.h
//  AR
//
//  Created by sonson on 11/02/06.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CameraController.h"

#if TARGET_IPHONE_SIMULATOR

@interface CameraController(simulator)
@end

#endif